import java.util.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
//import java.util.ArrayList;
/**
 * Write a description of class Hall here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Hall
{
    private String hallName;
    private HallOwner hallOwner;//deal with later
    private String description;
    private String address;
    private float depositPercentage;
    private float averageRating; //problem
    private float hallBasePrice;
    private int hallCapacity;
    //private ArrayList<AvailableDateTime> datesTimesAvailable;
    private HashMap<LocalDate,TimeSlot> datetimesNotAvailable;
    private LocalDate updateDate;
    private boolean hallIsAvailable;
    private ArrayList<Review> reviews;

    /**
     * Constructor for objects of class Hall
     */
    public Hall()
    {

    }

    public Hall(String newHallName, String newDesc,String newAddr,float newDepositPercen, float newHallBasePrice, int newHallCapacity,HashMap<LocalDate,TimeSlot> newDatetimesNotAvailable)
    {
        hallName = newHallName;
        description = newDesc;
        address = newAddr;
        depositPercentage = newDepositPercen;
        hallBasePrice = newHallBasePrice;
        hallCapacity = newHallCapacity;
        datetimesNotAvailable = newDatetimesNotAvailable;
        //timeslotNotAvailable = newTimeslotNotAvailable;
        hallIsAvailable = true;
        reviews = new ArrayList<Review>();
        //updateDates = new Date();
    }

    public Hall(String newHallName, String newDesc,String newAddr,float newDepositPercen, float newHallBasePrice, int newHallCapacity)
    //throws java.text.ParseException
    {
        hallName = newHallName;
        description = newDesc;
        address = newAddr;
        depositPercentage = newDepositPercen;
        hallBasePrice = newHallBasePrice;
        hallCapacity = newHallCapacity;
        hallIsAvailable = true;
        datetimesNotAvailable = new HashMap<LocalDate,TimeSlot>();
        reviews = new ArrayList<Review>();
        /**
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date availdate = format.parse("2019-10-08");
        for(int i = 0; i < 14; i++)
        {
        datesTimesAvailable.add(new AvailableDateTime(availdate));
        //LocalDateTime.from(availdate.toInstant()).plusDays(1);
        availdate = new Date(availdate.getTime() + 86400000);
        }
         **/
    }

    public String getHallName()
    {
        return hallName;
    }

    public void setHallName(String newHallName)
    {
        hallName = newHallName;
    }

    public String getHallDesc()
    {
        return description;
    }

    public void setHallDesc(String newHallDesc)
    {
        description = newHallDesc;
    }

    public String getHallAddr()
    {
        return address;
    }

    public void setHallAddr(String newHallAddr)
    {
        address = newHallAddr;
    }

    public float getDeposPercen()
    {
        return depositPercentage;
    }

    public void setDeposPercen(float newDesposPrecen)
    {
        depositPercentage = newDesposPrecen;
    }

    public float getAverageRating()
    {
        return averageRating;
    }

    public void setAverageRating(float newAvgRating)
    {
        averageRating = newAvgRating;
    }

    public float getHallBasePrice()
    {
        return hallBasePrice;
    }

    public void setHallBasePrice(float newHallBasePrice)
    {
        hallBasePrice = newHallBasePrice;
    }

    public int getHallCapacity()
    {
        return hallCapacity;
    }

    public void setHallCapacity(int newCapacity)
    {
        hallCapacity = newCapacity;
    }

    public void setHallDateTime()
    {

    }
    
    public void addReview(Review review)
    {
        reviews.add(review);
        float sum = 0;
        for (Review areview: reviews)
        {
            sum += areview.getRatingNo();
        }
        averageRating = sum/reviews.size();
        
        
        
    }
    /**
    public ArrayList<Date> getDateslotNotAvailable()
    {
    return datesHasNotAvailableTime;
    }

    public void setDatesHasNotAvailableTime(ArrayList<Date>newDatesHasNotAvailableTime)
    {
    datesHasNotAvailableTime = newDatesHasNotAvailableTime;
    }

    /**
    public int[][] getTimeslotAvailable()
    {
    return timeslotNotAvailable;
    }
     **/

    /**
    public void setTimeslotAvailable(int[][] newTimeslotNotAvailable)
    {
    timeslotNotAvailable = newTimeslotNotAvailable;
    }
     **/

    public boolean getHallIsAvailable()
    {
        return hallIsAvailable;
    }

    public void setHallIsAvailable(boolean newHallIsAvailable)
    {
        hallIsAvailable = newHallIsAvailable;
    }

    public LocalDate getUpdateDates()
    {
        return updateDate;
    }

    public void setUpdateDates(LocalDate newUpdateDates)
    {
        updateDate = newUpdateDates;
    }

    public HashMap<LocalDate,TimeSlot> getDatetimesNotAvailable()
    {
        return datetimesNotAvailable;
    }

    public void  setDatetimesNotAvailable(HashMap<LocalDate,TimeSlot> newDatetimesNotAvailable)
    {
        datetimesNotAvailable = newDatetimesNotAvailable; 
    }

    public ArrayList<Review> getReviews()
    {
        return reviews;
    }

    public void setBookings(ArrayList<Review> newReviews)
    {
        reviews = newReviews; 
    }

    /**
    checkStringIsBlank(String):boolean
     **/ 
    /**
    public boolean checkHallAvailable()
    {
    return hallIsAvailable == true;
    }
     **/
    /**
    AcceptInteger(String):int
     **/ 
}
