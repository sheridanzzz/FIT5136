import java.util.Scanner;
import java.util.ArrayList;
import java.time.LocalDate;

/**
 * Write a description of class PrimeEvent here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PrimeEvent
{
    private User logedInUser;
    private ListOfUser users;
    private ListOfHall halls;

    public PrimeEvent()
    {
        logedInUser = new User();
        halls = new ListOfHall();
        users = new ListOfUser();
        ArrayList<Hall> hallList = halls.getHalls();
        ArrayList<User> userList = users.getListOfUser();
        //Quotation(Customer newCustomer,Hall newHall,String newTypeOfEv, boolean newIsCatePref, int newNoOfPeopAttend,LocalDate newDate,TimeSlot newTime)
        //Customer cust1 = CuserList.get(0);
        //Quotation q1 = new Quotation((Customer)userList.get(0),hallList.get(0),"Birthday",false,15,LocalDate.of(2019,10,9),new TimeSlot(true,true,false));
        Review r1 = new Review(3,"so so",LocalDate.of(2019,10,11));
        userList.get(0).addBooking(new Booking(15.0f,new Quotation((Customer)userList.get(0),hallList.get(0),"Birthday",false,15,LocalDate.of(2019,10,9),new TimeSlot(true,true,false)),r1));
        hallList.get(0).addReview(r1);

        userList.get(0).addBooking(new Booking(20.0f,new Quotation((Customer)userList.get(0),hallList.get(1),"Anniversary",true,15,LocalDate.of(2019,10,11),new TimeSlot(true,false,true))));

        Review r2 = new Review(2,"not good",LocalDate.of(2019,10,14));
        userList.get(1).addBooking(new Booking(15.0f,new Quotation((Customer)userList.get(1),hallList.get(0),"Birthday",false,16,LocalDate.of(2019,10,13),new TimeSlot(true,false,true)),r2));
        hallList.get(0).addReview(r2);

        userList.get(1).addBooking(new Booking(20.0f,new Quotation((Customer)userList.get(1),hallList.get(1),"Anniversary",false,13,LocalDate.of(2019,10,13),new TimeSlot(false,true,true))));

        Review r3 = new Review(4,"cool",LocalDate.of(2019,10,18));
        userList.get(2).addBooking(new Booking(15.0f,new Quotation((Customer)userList.get(2),hallList.get(0),"Birthday",true,11,LocalDate.of(2019,10,16),new TimeSlot(false,true,true)),r3));
        hallList.get(0).addReview(r3);

        userList.get(2).addBooking(new Booking(20.0f,new Quotation((Customer)userList.get(2),hallList.get(1),"Anniversary",true,12,LocalDate.of(2019,10,16),new TimeSlot(false,false,false))));


    }

    public PrimeEvent(User newUser,ListOfHall newHallList,ListOfUser newUserList)
    {
        logedInUser = newUser;
        users = newUserList;
        halls = newHallList;
    }

    public void startSystem()
    {
        UserInterface boundary = new UserInterface();
        Scanner sc = new Scanner(System.in);
        int index = 0;
        boolean bool = false;
        boundary.displayWelcomeMessage();
        while(bool == false)
        {
            boundary.displayMainMenu();
            index = Integer.parseInt(sc.nextLine());
            if(index == 1)
            {
                loginAsCustomer();
                bool = true;
            }
            else if(index == 2)
            {
                System.out.println("Register function will coming soon...");
                bool = false;
            }
            else
                System.exit(0);
        }
        UserInterface.displayCustomerMainMenu();
    }

    public void loginAsCustomer()
    {
        Scanner scan = new Scanner(System.in);
        String inputEmail;
        String inputPasswd;
        UserInterface boundary = new UserInterface();
        boolean emailIsValid = false;
        int index = -1;
        while(index == -1)
        {
            boundary.displayLoginMenu();
            inputEmail = scan.nextLine();
            index = users.checkAUser(inputEmail);
            if(index == -1)
            {
                System.out.println("Please input a valid user account.");
            }
        }
        boolean passwdIsValid = false;
        while(passwdIsValid == false)
        {
            boundary.askForpasswd();
            //logedInUser = users.getListOfUser().get(index);
            Customer cust = (Customer)users.getListOfUser().get(index);
            inputPasswd = scan.nextLine();
            if (inputPasswd.equals(cust.getPassword()))
            {
                logedInUser = cust;
                System.out.println("Welcome back!" + logedInUser.getFname());
                System.out.println("Press Enter to Continue!");
                scan.nextLine();
                enterCustomerMenu();

                passwdIsValid = true;
            }
            else
            {
                System.out.println("Please input correct password!");
                //bol = false;
            }
        }
    }

    public void enterCustomerMenu()
    {
        Scanner scan = new Scanner(System.in);
        UserInterface boundary = new UserInterface();
        UserInterface.displayCustomerMainMenu();
        String choice = scan.nextLine();
        switch(choice)
        {
            case "1": selectViewAllHall(); break;
            //case "2": selectViewQuotations(); break;
            //case "3": selectViewBookings(); break;
            //case "4": logOut(); break;
            default: boundary.displayInvalidInput();
        }

    }

    public void selectViewAllHall()
    {
        Scanner scan = new Scanner(System.in);
        UserInterface boundary = new UserInterface();
        ArrayList<Hall> availaHalls = halls.getListOfAvailableHalls();
        UserInterface.displayAllHallInfo(halls.getListOfAvailableHalls());
        String choice = scan.nextLine();
        int hallindexNo = 0;
        while(true)
        {
            if (choice.equals("q"))
            {
                enterCustomerMenu();
                break;
            }
            try
            {
                hallindexNo = Integer.parseInt(choice);
            }
            catch(Exception e)
            {
                boundary.displayInvalidInput();
                scan.nextLine();
            }
            if (hallindexNo > 0 && hallindexNo < availaHalls.size()+1)
            {
                int index = hallindexNo -1;
                Hall selectedHall = availaHalls.get(index);
                selectAHall(selectedHall);
                //UserInterface.displayHallDetails(selectedHall);
                while(true)
                {

                    UserInterface.askForRFQ();
                    String choic = scan.nextLine();
                    if (choic.equals("y"))
                    {
                        setQuotation(selectedHall);
                        break;
                    }
                    if (choic.equals("n"))
                    {
                        //viewAllHalls();
                        break;
                    }
                    System.out.println("Invalid Input!");
                }
            }
        }

    }

    public void selectAHall(Hall hall)
    {
        UserInterface boundary = new UserInterface();
        boundary.diplayAHall(hall);
    }

    public float calculatePrice(Quotation quotation)
    {
        if(quotation.getIsCateringPreferred() == false)
            return quotation.getNoOfPeopleAttending() * quotation.getHall().getHallBasePrice();
        else
            return quotation.getNoOfPeopleAttending() * (quotation.getHall().getHallBasePrice() + 20);
    }

    public void setQuotation(Hall hall)
    {
        Scanner scan = new Scanner(System.in);
        UserInterface boundary = new UserInterface();
        boundary.displayQuotationMenu();
        Quotation quotation = new Quotation();
        String noOfPeople = scan.nextLine();
        int noOfpeople = Integer.parseInt(noOfPeople);
        quotation.setNoOfPeopleAttending(noOfpeople);
        quotation.setHall(hall);
        //quotation.setEstimatedPrice(calculatePrice(quotation));
        //boundary.displayEstimatedPrice(quotation.getEstimatedPrice());
        boundary.askForCaterPrefer();
        String caterpref = scan.nextLine();
        switch(caterpref)
        {
            case"y":
            quotation.setIscateringPreferred(true);
            break;
            case"n":
            quotation.setIscateringPreferred(false);
            break;
            default:
            boundary.displayInvalidInput();
            break;
        }
        quotation.setEstimatedPrice(calculatePrice(quotation));
        System.out.println("Your quotation information has been saved.");
        boundary.displayEstimatedPrice(quotation.getEstimatedPrice());
        boundary.displayQuotation(quotation);
    }

    public void customerMakeBooking(Quotation quotation)
    {

    }

    public void giveReview(Review review)
    {

    }
}
